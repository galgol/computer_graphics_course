#include <iostream>
#include "display.h"
#include "mesh.h"
#include "shader.h"
#include "debugTimer.h"
#include "inputManager.h"

using namespace glm;

int main(int argc,char** argv)
{
	Display display(800,600,"hello!");
	Shader shader("res/shaders/mbrot");
	Vertex vertices[] = {Vertex(vec3(-1,-1,0),vec2(0,0),vec3(0,0,1)),Vertex(vec3(1,-1,0),vec2(0,0),vec3(0,0,1)),Vertex(vec3(1,1,0),vec2(0,0),vec3(0,0,1)),Vertex(vec3(-1,1,0),vec2(0,0),vec3(0,0,1))};
	unsigned int indices[] = {0,1,2,0,2,3};
	Mesh mesh(vertices,4,indices,6);
	DebugTimer t;
	glfwSetKeyCallback(display.m_window,key_callback);

	while(!glfwWindowShouldClose(display.m_window))
	{

		display.Clear(0.0f, 0.0f, 0.0f, 1.0f);
		shader.Bind();
		shader.Update(t.GetTime());
	
		mesh.Draw();

		display.SwapBuffers();

		glfwPollEvents();
	}
	//getchar();
	return 0;
}